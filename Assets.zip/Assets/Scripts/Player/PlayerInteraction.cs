using UnityEngine;

namespace PlayerSystem
{
    public class PlayerInteraction : MonoBehaviour
    {
        [Header("Interaction Settings")]
        public float interactRange = 1.5f;   // ���� Ray �Ÿ�
        public float pickupRange = 1.2f;     // �ֺ� Ž�� �Ÿ�

        [Header("Layer Settings")]
        [Tooltip("��ȣ�ۿ�(FŰ)�� ������ ���̾���� �����մϴ�.")]
        public LayerMask interactableLayer;
        [Tooltip("������ �ݱ�(FŰ)�� ������ ���̾���� �����մϴ�.")]
        public LayerMask pickupLayer;

        private PlayerController controller;
        private PlayerHealth playerHealth;

        // ����� ǥ�ÿ� ����
        private Vector2 lastRayDir = Vector2.zero;
        private bool hitSomething = false;
        private string hitName = "";

        private void Awake()
        {
            controller = GetComponent<PlayerController>();
            playerHealth = GetComponent<PlayerHealth>();
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F))
                TryInteract();
        }

        private void TryInteract()
        {
            Vector2 pos = transform.position;
            Vector2 dir = controller.LastMoveDir;
            lastRayDir = dir;

            hitSomething = false;
            hitName = "";

            Debug.Log($"[TryInteract] Ray ����: {dir}, �Ÿ�: {interactRange}");

            //  ���� Raycast (NPC, �� ��)
            RaycastHit2D hitFront = Physics2D.Raycast(pos, dir, interactRange, interactableLayer);
            if (hitFront.collider != null)
            {
                hitSomething = true;
                hitName = hitFront.collider.name;

                Debug.Log($"���� ������: {hitFront.collider.name}");

                var interactable = hitFront.collider.GetComponentInParent<IInteractable>();

                if (interactable != null)
                {
                    interactable.Interact(this, playerHealth);
                    return;
                }

                return;
            }

            //  �ֺ� ������ Ž�� (Pickup Layer)
            Collider2D[] hitAround = Physics2D.OverlapCircleAll(pos, pickupRange, pickupLayer);
            foreach (var col in hitAround)
            {
                hitSomething = true;
                hitName = col.name;

                var pickup = col.GetComponentInParent<IPickup>();
                if (pickup != null)
                {
                    pickup.Pickup(this);
                    return;
                }
            }

            //  �ƹ� ��ȣ�ۿ� ��� ���� ���� �α� ���
            if (!hitSomething)
            {
                Debug.Log("��ȣ�ۿ� ������ ������Ʈ ����");
            }
        }

        //  Scene �� �ð�ȭ
        private void OnDrawGizmos()
        {
            if (!Application.isPlaying || controller == null)
                return;

            Gizmos.color = hitSomething ? Color.green : Color.red;
            Gizmos.DrawRay(transform.position, lastRayDir * interactRange);

            Gizmos.color = new Color(1f, 1f, 0f, 0.3f);
            Gizmos.DrawWireSphere(transform.position, pickupRange);

#if UNITY_EDITOR
            if (hitSomething && !string.IsNullOrEmpty(hitName))
            {
                UnityEditor.Handles.Label(
                    transform.position + (Vector3)lastRayDir * interactRange,
                    $"Hit: {hitName}"
                );
            }
#endif
        }
    }
}