using UnityEngine;
using TMPro;

public class DialogueUI : MonoBehaviour
{
    public static DialogueUI Instance;  // �̱��� ���ٿ�

    [Header("UI References")]
    public GameObject dialoguePanel;
    public TextMeshProUGUI npcNameText;
    public TextMeshProUGUI dialogueText;

    private bool isActive = false;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        // Canvas ��ü�� �ѵΰ�, ���� Panel�� ���� ����
        if (dialoguePanel != null)
            dialoguePanel.SetActive(false);
    }


    // ��ȭâ ����
    public void OpenDialogue(string npcName, string firstLine)
    {
        dialoguePanel.SetActive(true);
        npcNameText.text = npcName;
        dialogueText.text = firstLine;
        isActive = true;
    }

    // ���� ���� ǥ��
    public void UpdateDialogue(string line)
    {
        dialogueText.text = line;
    }

    // �ݱ�
    public void CloseDialogue()
    {
        dialoguePanel.SetActive(false);
        isActive = false;
    }

    public bool IsOpen() => isActive;
}
